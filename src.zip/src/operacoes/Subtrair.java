package operacoes;

public class Subtrair {
    public void realizarOperacao(double var1, double var2) {
        System.out.printf("Resultado %.2f - %.2f = %.2f", var1, var2,(var1 - var2));
    }
}
