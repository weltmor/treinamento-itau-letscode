package br.com.letscode.turmaitau;

public class PrimeiraClasse {
    public static void main(String[] args) {
        byte primeiraVariavelByte = '1';
        System.out.println("Byte = " + primeiraVariavelByte);
        System.out.println("Hello Itau");
    }
}
